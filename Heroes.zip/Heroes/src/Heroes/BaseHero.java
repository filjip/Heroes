package Heroes;

public abstract class BaseHero<string> {
    public double health;
    public double mana;
    public boolean dead;

    public abstract void primaryFire();
    public abstract void receiveHit();
    public abstract void reciveHealth();

    public abstract void show();
}