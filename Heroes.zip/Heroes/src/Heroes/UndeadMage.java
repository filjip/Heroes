package Heroes;

public class UndeadMage extends BaseHero {
    
    public UndeadMage (int magija, int zdravlje, boolean mrtav) {
        mana = magija;
        health = zdravlje;
        dead = mrtav;
    }

    @Override
    public void primaryFire() {
        
    }

    @Override
    public void receiveHit() {

    }

    @Override
    public void reciveHealth() {
        if (this.health != 0) {
            this.health -=10;
        }
        else {
            this.health = 10;
            this.dead = false;
            System.out.println("Undademage");
            System.out.println("undeadMage got 10 health");
            System.out.println("Health: " + this.health);
            System.out.println("Mana: " + this.mana);
            System.out.println("Dead: " + this.dead);
    }
        }

    @Override
    public void show() {

    }
}