package Heroes;

import java.sql.SQLOutput;

public class Main {

    public static void main(String[] args) {
        //Napravili smo constructor koji prima 3 argumenta (magija, zdravlje, mrtav)
        HumanWarrior humanWarrior2 = new HumanWarrior("humanWarrior", 20, 20, true);

        //Ovako dodijeljujemo vrijednosti variablama tom objektu bez metode constructora
        HumanWarrior humanWarrior = new HumanWarrior();
        humanWarrior.dead = false;
        humanWarrior.health = 20;
        humanWarrior.mana = 20;
        humanWarrior.show();

        Mage mage = new Mage(20, 1, false);
        System.out.println(mage.dead);

        Elf Elf = new Elf(20, 20, false) {

            @Override
            public void show() {

            }
        };

        UndeadMage undeadMage = new UndeadMage(20, 0, false);
        double health; {;
        System.out.println("Mage got 10 health");
    }
}}