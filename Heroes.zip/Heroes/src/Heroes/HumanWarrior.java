package Heroes;

public class HumanWarrior extends BaseHero {

    public HumanWarrior(String humanWarrior, int magija, int zdravlje, boolean mrtav){
    }

    //Constructor koji prima 3 argumenta (magija, zdravlje, mrtav)
    //i sprema ih u variable (mana, health, dead)
    public <name> HumanWarrior(int magija, int zdravlje, boolean mrtav){
        mana = magija;
        health = zdravlje;
        dead = mrtav;
    }

    public HumanWarrior() {

    }

    @Override
    public void primaryFire() {
        this.mana -= 10;
        System.out.println("Primary Fire! i did 20 damage to enemy");
    }

    @Override
    public void receiveHit() {
        if (this.health != 0) {
            this.health -=10;
        }
        else {
            this.health = 0;
            this.dead = true;
            System.out.println("i'm dead!!!");
        }
    }

    @Override
    public void reciveHealth() {
        System.out.println("UndeadMage");
        System.out.println("Health: " + this.health);
        System.out.println("Mana: " + this.mana);
        System.out.println("Dead: " + this.dead);
    }

    @Override
    public void show() {

    }


    }