package Heroes;

public abstract class Elf extends BaseHero {

    public Elf(int magija, int zdravlje, boolean mrtav) {
            mana = magija;
            health = zdravlje;
            dead = mrtav;
        }
    @Override
    public void primaryFire() {
        this.mana -= 15;
        System.out.println("Fire, i did 15 damage to enemy");
    }

    @Override
    public void receiveHit() {
    if (this.health != 0) {
        this.health -=15;
    }
    else {
        this.health = 0;
        this.dead = true;
        System.out.println("I'm dead!");
    }
}

    @Override
    public void reciveHealth() {

    }
}
