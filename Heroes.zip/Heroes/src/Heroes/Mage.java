package Heroes;

public class Mage extends BaseHero {
    public Mage(int magija, int zdravlje, boolean mrtav) {
        mana = magija;
        health = zdravlje;
        dead = mrtav;
    }
    public void primaryFire() {
        System.out.println("Mage hit you.");
    }

    public void receiveHit() {
        System.out.println("Mage is dead.");
    }

    @Override
    public void reciveHealth() {

    }

    @Override
    public void show() {

    }
}
